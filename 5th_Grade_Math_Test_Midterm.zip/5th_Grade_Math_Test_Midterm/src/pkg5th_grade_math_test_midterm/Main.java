/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkg5th_grade_math_test_midterm;
import java.util.Scanner;

/**
 *
 * @author kevin
 */
public class Main 
{


    public static void main(String[] args)
    {
            try
            {
                Scanner scan = new Scanner(System.in);
                System.out.println("Select one of the binary operators");
                System.out.println();
                System.out.println("1. Addition.");
                System.out.println("2. Subtraction.");
                System.out.println("3. Multiplication.");
                System.out.println("4. Division.");
                System.out.println();
                System.out.println("Enter your selection ");
                int selection = scan.nextInt();
                int correct_selection = 0;
                correct_selection = kid_selection(selection);
                //created an interface for the user to select one of the binary operators 
            }
            catch (Exception ex)
            {
                System.out.println("Error: LBJ23 Please select the correct choice.");
            }//created a catch method so the user doesn't select an incorrect value.
            
    } //end of the main
        public static int kid_selection(int fifth)
        {
            Scanner scan1 = new Scanner(System.in);
                    
            while (fifth < 1 || fifth > 5)
            {
                System.out.println();
                System.out.println("Error code Bronny: Enter the correct selection");
                fifth = scan1.nextInt();
                //this section prevents from getting infinite error codes even if the user entered the correct selection
            }
                    
            int max_tries = 2;
            int min_tries = 1;
            for (int counter = 0; counter < max_tries; counter ++)
              /*  {
                    if (fifth > 0 && fifth < 5)
                    {
                        break;
                    }
                    System.out.println();
                    min_tries = max_tries - counter;
                    System.out.println("LBJ2020 code: Try again," + min_tries + "chances left");
                        
                    }
                */   
            do
            {
                if (fifth > 0 && fifth < 5)
                {
                    break;
                }
                System.out.println();
                System.out.print("Error: Please enter a valid selection");
                fifth = scan1.nextInt();
            }
                while (fifth < 1 || fifth > 4);
            
            return fifth;
                    
            
                    //{
        //int min = 1;
        //int max = 10;
        //int range = max - min + 1; //didn't wanna start with a 0 so added a +1 to avoid that
        
        //System.out.println( (int)(Math.random() * range ) + min);
    //}
            }
            }

